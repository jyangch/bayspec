# BaySpec
A Bayesian inference-based spectral fitting tool for multi-dimensional (time and energy) and multi-wavelength (X-ray and gamma-ray) astrophysical data.
